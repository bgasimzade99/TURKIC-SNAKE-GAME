import pygame
import cv2  # For handling the MP4 video
import time
import random

# Initialize Pygame
pygame.init()

# Game Window Dimensions
WIDTH, HEIGHT = 800, 600
CELL_SIZE = 20

# Colors
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLACK = (0, 0, 0)

# Create Window
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Snake Game")

# Clock for controlling speed
clock = pygame.time.Clock()

# Difficulty Modes
DIFFICULTY = {
    "Easy": 10,
    "Medium": 15,
    "Hard": 20
}

# Load Music
pygame.mixer.init()
lobby_sound = pygame.mixer.Sound("turk.mp3")  # Lobby music
move_sound = pygame.mixer.Sound("music_move.mp3")  # Snake move sound
food_sound = pygame.mixer.Sound("music_food.mp3")  # Eating food sound
gameover_sound = pygame.mixer.Sound("music_gameover.mp3")  # Game Over sound

# Best Score Tracker
best_score = 0

# Load and resize the logo
logo = pygame.image.load("rtu1.png")  # Replace with the correct path to your logo
logo_width, logo_height = 80, 80  # Adjust as needed
logo = pygame.transform.scale(logo, (logo_width, logo_height))


# Snake and Food Initialization
def start_game(speed):
    global best_score

    snake_pos = [[100, 100], [90, 100], [80, 100]]  # Snake initial size
    food_pos = [random.randrange(1, WIDTH // CELL_SIZE) * CELL_SIZE,
                random.randrange(1, HEIGHT // CELL_SIZE) * CELL_SIZE]
    direction = 'RIGHT'
    change_to = direction
    score = 0

    running = True
    while running:
        screen.fill(BLACK)

        # Event Handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP and direction != 'DOWN':
                    change_to = 'UP'
                elif event.key == pygame.K_DOWN and direction != 'UP':
                    change_to = 'DOWN'
                elif event.key == pygame.K_LEFT and direction != 'RIGHT':
                    change_to = 'LEFT'
                elif event.key == pygame.K_RIGHT and direction != 'LEFT':
                    change_to = 'RIGHT'

        direction = change_to

        # Update Snake Position
        if direction == 'UP':
            snake_pos.insert(0, [snake_pos[0][0], snake_pos[0][1] - CELL_SIZE])
        elif direction == 'DOWN':
            snake_pos.insert(0, [snake_pos[0][0], snake_pos[0][1] + CELL_SIZE])
        elif direction == 'LEFT':
            snake_pos.insert(0, [snake_pos[0][0] - CELL_SIZE, snake_pos[0][1]])
        elif direction == 'RIGHT':
            snake_pos.insert(0, [snake_pos[0][0] + CELL_SIZE, snake_pos[0][1]])
            move_sound.play()

        # Check if Snake Ate Food
        if snake_pos[0] == food_pos:
            score += 1
            food_sound.play()
            food_pos = [random.randrange(1, WIDTH // CELL_SIZE) * CELL_SIZE,
                        random.randrange(1, HEIGHT // CELL_SIZE) * CELL_SIZE]
        else:
            snake_pos.pop()

        # Check Collision with Walls or Itself
        if (snake_pos[0][0] < 0 or snake_pos[0][0] >= WIDTH or
                snake_pos[0][1] < 0 or snake_pos[0][1] >= HEIGHT or
                snake_pos[0] in snake_pos[1:]):
            running = False
            gameover_sound.play()
            game_over(score)

        # Draw Snake and Food
        pygame.draw.rect(screen, RED, pygame.Rect(food_pos[0], food_pos[1], CELL_SIZE, CELL_SIZE))
        for pos in snake_pos:
            pygame.draw.rect(screen, GREEN, pygame.Rect(pos[0], pos[1], CELL_SIZE, CELL_SIZE))

        # Display Score
        show_score(score)

        pygame.display.flip()
        clock.tick(speed)


# Display Score
def show_score(score):
    font = pygame.font.Font(None, 30)
    text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(text, [10, 10])


# Game Over Screen
def game_over(score):
    global best_score
    if score > best_score:
        best_score = score  # Update the best score if the current score is higher

    screen.fill(BLACK)
    font = pygame.font.Font(None, 40)

    # Game Over text
    game_over_text = font.render(f"Game Over! Score: {score}", True, RED)
    screen.blit(game_over_text, [WIDTH // 4, HEIGHT // 3])

    # Best Score text
    best_score_text = font.render(f"Best Score: {best_score}", True, WHITE)
    screen.blit(best_score_text, [WIDTH // 4, HEIGHT // 3 + 50])

    # Logo and Credits
    logo_x = 10
    logo_y = HEIGHT - logo_height - 10
    screen.blit(logo, (logo_x, logo_y))
    credit_text = font.render("Created by TURKIC GROUP", True, WHITE)
    credit_text_x = logo_x + logo_width + 10
    credit_text_y = HEIGHT - 30
    screen.blit(credit_text, (credit_text_x, credit_text_y))

    pygame.display.flip()
    time.sleep(2)


# Difficulty Selection Menu
def menu():
    # Play Lobby Music
    lobby_sound.play(-1)  # Loop the lobby music

    cap = cv2.VideoCapture("snak2.mp4")  # Replace with your MP4 file path
    if not cap.isOpened():
        print(f"Error: Cannot open video file.")
        return

    alpha = 0  # Initial transparency (0 is fully transparent)
    fade_duration = 250  # Number of frames to fully fade in

    while True:
        ret, frame = cap.read()
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)  # Restart the video
            ret, frame = cap.read()

        # Render video frame
        frame = cv2.resize(frame, (300, 200))  # Resize to fit
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame_surface = pygame.surfarray.make_surface(frame.swapaxes(0, 1))

        # Apply fade-in effect
        if alpha < 255:  # Max alpha is 255 (fully visible)
            alpha += 255 // fade_duration  # Gradually increase alpha
            frame_surface.set_alpha(alpha)

        # Render other elements
        screen.fill(BLACK)
        screen.blit(frame_surface, (270, 150))  # Display the video at the center

        # Welcome Text
        title_font = pygame.font.Font(None, 60)
        welcome_text = title_font.render("Welcome to the SNAKE GAME!", True, RED)
        screen.blit(welcome_text, (WIDTH // 6, HEIGHT // 9))

        # Difficulty Options
        font = pygame.font.Font(None, 30)
        text = font.render("Choose Difficulty: E (Easy) / M (Medium) / H (Hard)", True, WHITE)
        text_x = 200  # Align with the video
        text_y = 420  # Below the snake head
        screen.blit(text, (text_x, text_y))

        # Logo and Credits
        logo_x = 10
        logo_y = HEIGHT - logo_height - 10
        screen.blit(logo, (logo_x, logo_y))
        credit_text = font.render("Created by TURKIC GROUP", True, WHITE)
        credit_text_x = logo_x + logo_width + 10
        credit_text_y = HEIGHT - 30
        screen.blit(credit_text, (credit_text_x, credit_text_y))

        pygame.display.flip()

        # Handle menu events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                lobby_sound.stop()
                cap.release()
                pygame.quit()
                exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_e:
                    lobby_sound.stop()
                    cap.release()
                    start_game(DIFFICULTY["Easy"])
                elif event.key == pygame.K_m:
                    lobby_sound.stop()
                    cap.release()
                    start_game(DIFFICULTY["Medium"])
                elif event.key == pygame.K_h:
                    lobby_sound.stop()
                    cap.release()
                    start_game(DIFFICULTY["Hard"])


# Run Game Menu
menu()
pygame.quit()
